Ext.define('MyExtGenApp.view.home.HomeViewController', {
	extend: 'Ext.app.ViewController',
	alias: 'controller.homeviewcontroller',


	submit: function () {
        var form = this.getView();

        if (form.validate()) {
            Ext.toast('Form is valid!');
        } else {
            Ext.toast('Form is invalid, please correct the errors.');
        }
	}

		
	//callIsValid: function () {
       // var field = this.lookup('markInvalidTest'),
           // isValid = field.isValid();

        //Ext.Msg.alert('Called isValid()', 'Field is valid: ' + (isValid ? 'true' : 'false'));
   // }


});
