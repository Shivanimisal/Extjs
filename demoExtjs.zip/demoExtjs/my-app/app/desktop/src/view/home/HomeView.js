Ext.define('MyExtGenApp.view.home.HomeView',{
	xtype: 'homeview',
	cls: 'left-right-buttons',
	controller: {type: 'homeviewcontroller'},
	viewModel: {type: 'homeviewmodel'},
	requires: [],
	extend: 'Ext.Container',
	extend: 'Ext.form.Panel',
    scrollable: true,
    title: 'Welcome',
	bodyPadding: 80,
    defaultType: 'textfield',
    scollable: 'y',
    autoSize: true,
		items: [
			
			{
				xtype: 'textfield',
				name : 'firstName',
				label: 'First Name',
				msgTarget: 'under',
				allowBlank: false,
				minLength: 3,
				maxLength: 15
			},
			{
				xtype: 'textfield',
				name : 'lastName',
				label: 'Last Name',
				msgTarget: 'under',
				allowblank: false,
				minLength: 3,
				maxLength: 15
			},


			{
				xtype: 'textfield',
				name : 'location',
				label: 'Office location',
				msgTarget: 'under', 
				allowblank:false,
				minLength: 5,
				maxLength: 40
			}, 

			{
				xtype: 'textfield',
				name : 'Phone',
				label: 'Phone',
				vtype: 'phone',
				msgTarget: 'under', 
				allowblank: 'false',
				minLength: 10,
				maxLength: 10
			},
			
			{
				xtype: 'textfield',
				name: 'email',
				label: 'Email Address',
				vtype: 'email',
			},

			{
				xtype: 'datefield',
				label: 'Date of Birth',
				name: 'birthDate',
				msgTarget: 'under', 
				invalidText: '"{0}" bad. "{1}" good.'
			},


		
		],

		buttons : [ 
			{
			xtype : 'button',
			text : 'Submit',
			cls:'button',
			handler:'submit',
		    align : 'center',
			height : 50,
			width : 200,
			maximizable : true,


		} ],


	








	

	

});





