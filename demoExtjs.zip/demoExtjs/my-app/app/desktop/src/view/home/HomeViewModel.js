Ext.define('MyExtGenApp.view.home.HomeViewModel', {
	extend: 'Ext.app.ViewModel',
	alias: 'viewmodel.homeviewmodel',
	data: {
		name: 'homeview'
	},

});
