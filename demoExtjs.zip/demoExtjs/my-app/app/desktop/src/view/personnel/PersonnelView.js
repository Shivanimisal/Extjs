Ext.define('MyExtGenApp.view.personnel.PersonnelView',{
    extend: 'Ext.grid.Grid',
    //extend: 'Ext.Container',
    extend: 'Ext.grid.Panel',

    xtype: 'personnelview',
    cls: 'personnelview',
     requires: ['Ext.grid.rowedit.Plugin','Ext.Container'],
    controller: {type: 'personnelviewcontroller'},
     viewModel: {type: 'personnelviewmodel'},
    store: {type: 'personnelviewstore'},
    grouped: true,
    groupFooter: {
        xtype: 'gridsummaryrow'
    },
    plugins: {
        rowedit: {
            autoConfirm: false
        }
    },
    items   : [
        {
            xtype: 'button',
            text : 'Edit',
            cls:'button',
            height : 60,
			width : 300,
           
        },
        
        {
            xtype: 'button',
            text : 'Delete',
            cls:'button',
            height : 60,
			width : 300,
       
        },
    
    ],

    columns: [
        {
            text: 'Name',
            dataIndex: 'name',
            editable: true,
            width: 150
        },
        {
            text: 'Email',
            dataIndex: 'email',
            editable: true, 
            width: 230
        },

        {
            text: 'Phone',
            dataIndex: 'phone',
            editable: true,
            width: 150
        },
        {
            text: 'Office Location',
            dataIndex: 'location',
            editable: true,
            width: 150
        },
        
    ],
    // renderTo: Ext.getBody(),
    //   selModel: {
    //       selType: 'checkboxmodel'
    //   },


    listeners: {
        canceledit: 'onEditCancelled'
    },
    
});
