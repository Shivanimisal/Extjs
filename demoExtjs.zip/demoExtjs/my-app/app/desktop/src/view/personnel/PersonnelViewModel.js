Ext.define('MyExtGenApp.view.personnel.PersonnelViewModel', {
	extend: 'Ext.app.ViewModel',
	alias: 'viewmodel.personnelviewmodel',
	data: {
		name: 'MyExtGenApp'
	}
});
