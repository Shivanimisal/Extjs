Ext.define('MyExtGenApp.view.personnel.PersonnelViewStore', {
    extend: 'Ext.data.Store',
    alias: 'store.personnelviewstore',
    
    fields: [

        {name: 'name',  type: 'string'},
        {name: 'location',    type: 'string'},
        {name: 'email',  type: 'string'},
        {name: 'phone', type: 'string'}
    ],
 
    data: { items: [
        { name: 'Jean Luc',  location: "London",   email: "Sincere@april.biz", phone: "555-111-1111" },
        { name: 'ModernWorf',location: "New York", email: "worf.moghsson@enterprise.com",  phone: "555-222-2222"},
        { name: 'Deanna',    location: "Paris",    email: "deanna.troi@enterprise.com",    phone: "555-333-3333" },
        { name: 'Data',      location: "London",   email: "mr.data@enterprise.com",        phone: "555-444-4444" },
        { name: 'Leanne Graham',    location: "London",   email: "jeanluc.picard@enterprise.com", phone: "555-111-9999" },
        { name: 'Ervin Howell',     location: "New York", email: "Shanna@melissa.tv",             phone: "555-222-8888"},
        { name: 'Clementine Bauch', location: "Paris",    email: "Nathan@yesenia.net",            phone: "555-333-7777" },
        { name: 'Patricia Lebsack', location: "London",   email: "Julianne.OConner@kory.org",     phone: "555-444-6666" }
    ]},
    proxy: {
        type: 'memory',
        reader: {
            type: 'json',
            rootProperty: 'items'
        }
    }
});
