Ext.application({
	extend: 'MyExtGenApp.Application',
	name: 'Demo App'
});